const { DataTypes } = require('sequelize');
const sequelize = require('../config/db'); // Ensure this path is correct

const Member = sequelize.define('Member', {
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true, // Ensure email is unique across all members
  },
  phoneNumber: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true, // Ensure phone number is unique across all members
  },
  location: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  schoolId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Schools',
      key: 'id',
    }
  }
});

module.exports = Member;

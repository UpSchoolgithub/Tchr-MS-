module.exports = (sequelize, DataTypes) => {
  class ClassInfo extends sequelize.Sequelize.Model {}
  ClassInfo.init({
    className: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    academicStartDate: DataTypes.DATE,
    academicEndDate: DataTypes.DATE,
    revisionStartDate: DataTypes.DATE,
    revisionEndDate: DataTypes.DATE,
  }, {
    sequelize,
    modelName: 'ClassInfo'
  });

  ClassInfo.associate = (models) => {
    ClassInfo.hasMany(models.Section, { foreignKey: 'classId', onDelete: 'CASCADE' });
  };

  return ClassInfo;
};

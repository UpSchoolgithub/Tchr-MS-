module.exports = (sequelize, DataTypes) => {
  class Subject extends sequelize.Sequelize.Model {}
  Subject.init({
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    modelName: 'Subject'
  });

  Subject.associate = (models) => {
    Subject.belongsTo(models.Section, { foreignKey: 'sectionId' });
  };

  return Subject;
};

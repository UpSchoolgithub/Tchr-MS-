// models/TeacherSection.js
module.exports = (sequelize, DataTypes) => {
    const TeacherSection = sequelize.define('TeacherSection', {});
    return TeacherSection;
  };
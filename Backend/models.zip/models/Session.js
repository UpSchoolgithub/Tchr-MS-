const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Session = sequelize.define('Session', {
  schoolId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  classId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  sectionId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  chapterName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  numberOfSessions: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  priorityNumber: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: 'compositeIndex'
  }
}, {
  indexes: [
    {
      unique: true,
      fields: ['sectionId', 'priorityNumber']
    }
  ]
});

module.exports = Session;

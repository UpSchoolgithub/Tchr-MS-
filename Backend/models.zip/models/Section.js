module.exports = (sequelize, DataTypes) => {
  class Section extends sequelize.Sequelize.Model {}
  Section.init({
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    modelName: 'Section'
  });

  Section.associate = (models) => {
    Section.belongsTo(models.ClassInfo, { foreignKey: 'classId' });
    Section.hasMany(models.Subject, { foreignKey: 'sectionId', onDelete: 'CASCADE' });
  };

  return Section;
};

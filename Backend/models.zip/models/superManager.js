module.exports = (sequelize, DataTypes) => {
  const SuperManagerUser = sequelize.define('SuperManagerUser', {
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    }
  });

  SuperManagerUser.associate = function(models) {
    // Define associations here if needed
  };

  return SuperManagerUser;
};

// models/TeacherClass.js
module.exports = (sequelize, DataTypes) => {
    const TeacherClass = sequelize.define('TeacherClass', {});
    return TeacherClass;
  };
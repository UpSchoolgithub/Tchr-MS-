module.exports = (sequelize, DataTypes) => {
  class SessionPlan extends sequelize.Sequelize.Model {}
  SessionPlan.init({
    sessionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    planDetails: {
      type: DataTypes.TEXT,
      allowNull: false,
      defaultValue: 'Type your topic here', // Ensure this field has a default value
    },
    sessionNumber: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  }, {
    sequelize,
    modelName: 'SessionPlan'
  });

  return SessionPlan;
};

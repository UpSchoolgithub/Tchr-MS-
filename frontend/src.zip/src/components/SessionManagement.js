import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';

const SessionManagement = () => {
  const { schoolId, classId, sectionId } = useParams();
  const [sessions, setSessions] = useState([]);
  const [chapterName, setChapterName] = useState('');
  const [numberOfSessions, setNumberOfSessions] = useState('');
  const [priorityNumber, setPriorityNumber] = useState('');
  const [editingSessionId, setEditingSessionId] = useState(null);
  const [editingNumberOfSessions, setEditingNumberOfSessions] = useState('');
  const [editingPriorityNumber, setEditingPriorityNumber] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/schools/${schoolId}/classes/${classId}/sections/${sectionId}/sessions`);
        setSessions(response.data);
      } catch (error) {
        console.error('Error fetching sessions:', error);
      }
    };

    fetchSessions();
  }, [schoolId, classId, sectionId]);

  const handleSessionSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const response = await axios.post(`http://localhost:5000/api/schools/${schoolId}/classes/${classId}/sections/${sectionId}/sessions`, {
        chapterName,
        numberOfSessions,
        priorityNumber
      });
      setSessions([...sessions, response.data]);
      setChapterName('');
      setNumberOfSessions('');
      setPriorityNumber('');
    } catch (error) {
      console.error('Error adding session:', error);
      if (error.response && error.response.data) {
        setError(error.response.data.error);
      }
    }
  };

  const handleSessionUpdate = async (sessionId) => {
    setError('');
  
    try {
      const response = await axios.put(`http://localhost:5000/api/schools/${schoolId}/classes/${classId}/sections/${sectionId}/sessions/${sessionId}`, {
        numberOfSessions: editingNumberOfSessions,
        priorityNumber: editingPriorityNumber
      });
      setSessions(sessions.map(session => (session.id === sessionId ? response.data : session)));
      setEditingSessionId(null); // Exit editing mode after saving
  
      // Update the number of session plans
      await axios.put(`http://localhost:5000/api/sessions/${sessionId}/sessionPlans`, {
        numberOfSessions: editingNumberOfSessions
      });
  
    } catch (error) {
      console.error('Error updating session:', error);
      if (error.response && error.response.data) {
        setError(error.response.data.error);
      }
    }
  };

  const handleSessionDelete = async (sessionId) => {
    try {
      await axios.delete(`http://localhost:5000/api/schools/${schoolId}/classes/${classId}/sections/${sectionId}/sessions/${sessionId}`);
      setSessions(sessions.filter(session => session.id !== sessionId));
    } catch (error) {
      console.error('Error deleting session:', error);
    }
  };

  const startEditing = (session) => {
    setEditingSessionId(session.id);
    setEditingNumberOfSessions(session.numberOfSessions);
    setEditingPriorityNumber(session.priorityNumber);
  };

  const cancelEditing = () => {
    setEditingSessionId(null);
  };

  return (
    <div>
      <h2>Session Management</h2>
      {error && <div className="error">{error}</div>}
      <form onSubmit={handleSessionSubmit}>
        <div>
          <label>Chapter Name:</label>
          <input type="text" value={chapterName} onChange={(e) => setChapterName(e.target.value)} required />
        </div>
        <div>
          <label>Number of Sessions:</label>
          <input type="number" value={numberOfSessions} onChange={(e) => setNumberOfSessions(e.target.value)} required />
        </div>
        <div>
          <label>Priority Number:</label>
          <input type="number" value={priorityNumber} onChange={(e) => setPriorityNumber(e.target.value)} required />
        </div>
        <button type="submit">Save</button>
      </form>

      <table>
        <thead>
          <tr>
            <th>Chapter</th>
            <th>Number of Sessions</th>
            <th>Priority Number</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {sessions.map(session => (
            <tr key={session.id}>
              <td>{session.chapterName}</td>
              <td>
                {editingSessionId === session.id ? (
                  <input
                    type="number"
                    value={editingNumberOfSessions}
                    onChange={(e) => setEditingNumberOfSessions(e.target.value)}
                  />
                ) : (
                  session.numberOfSessions
                )}
              </td>
              <td>
                {editingSessionId === session.id ? (
                  <input
                    type="number"
                    value={editingPriorityNumber}
                    onChange={(e) => setEditingPriorityNumber(e.target.value)}
                  />
                ) : (
                  session.priorityNumber
                )}
              </td>
              <td>
                {editingSessionId === session.id ? (
                  <>
                    <button onClick={() => handleSessionUpdate(session.id)}>Save</button>
                    <button onClick={cancelEditing}>Cancel</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => startEditing(session)}>Edit</button>
                    <button onClick={() => handleSessionDelete(session.id)}>Delete</button>
                    <Link to={`/sessions/${session.id}/sessionPlans`}>
                      <button>Session Plan</button>
                    </Link>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SessionManagement;

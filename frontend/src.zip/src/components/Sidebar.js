import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
    return (
        <div className="sidebar">
            <div className="sidebar-logo">
                <img src="/Upschool_2x.png" alt="UpSchool Logo" />
            </div>
            <ul>
                <li><Link to="/dashboard">Dashboard</Link></li>
                <li><Link to="/create-school">School</Link></li>
                <li><Link to="/manager">Manager</Link></li>

            </ul>
        </div>
    );
};

export default Sidebar;

import React, { useState } from 'react';

const LoginForm = ({ setToken }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Define hardcoded credentials
  const hardcodedUsername = 'bhavyashree@up.school';
  const hardcodedPassword = '123';

  const handleLogin = async (e) => {
    e.preventDefault();
    // Validate the credentials
    if (username === hardcodedUsername && password === hardcodedPassword) {
      setToken('mock-token'); // Set a mock token for simplicity
      setError(''); // Clear any previous errors
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>Username</label>
          <input type="text" name="username" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div>
          <label>Password</label>
          <input type="password" name="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <button type="submit">Login</button>
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </form>
    </div>
  );
};

export default LoginForm;

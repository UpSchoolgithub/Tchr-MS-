import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import axios from 'axios';

const TimetableSettings = () => {
  const { schoolId } = useOutletContext();
  const [settings, setSettings] = useState({
    periodsPerDay: '',
    durationPerPeriod: '',
    schoolStartTime: '',
    schoolEndTime: '',
    assemblyStartTime: '',
    assemblyEndTime: '',
    lunchStartTime: '',
    lunchEndTime: '',
    shortBreak1StartTime: '',
    shortBreak1EndTime: '',
    shortBreak2StartTime: '',
    shortBreak2EndTime: '',
    reserveType: 'time',
    reserveDay: [],
    reserveTimeStart: '',
    reserveTimeEnd: '',
    reserveDayStart: '',
    reserveDayEnd: ''
  });
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTimetable = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/schools/${schoolId}/timetable`);
        const data = response.data;

        if (data.reserveDay) {
          data.reserveDay = data.reserveDay.split(',');
        } else {
          data.reserveDay = [];
        }

        setSettings(data);
      } catch (error) {
        if (error.response && error.response.status === 404) {
          console.error('Timetable settings not found for this school.');
          setError('Timetable settings not found.');
        } else {
          console.error('Failed to fetch timetable settings:', error);
          setError('Failed to fetch timetable settings.');
        }
      }
    };

    if (schoolId) {
      fetchTimetable();
    }
  }, [schoolId]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === 'checkbox') {
      setSettings((prevSettings) => ({
        ...prevSettings,
        [name]: checked
          ? [...prevSettings[name], value]
          : prevSettings[name].filter(day => day !== value)
      }));
    } else {
      setSettings((prevSettings) => ({
        ...prevSettings,
        [name]: value
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/api/schools/${schoolId}/timetable`, settings);
      alert('Timetable settings saved successfully!');
    } catch (error) {
      console.error('Error saving timetable settings:', error);
      alert('Failed to save timetable settings.');
    }
  };

  return (
    <div>
      <h2>Timetable Settings</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Periods Per Day:</label>
          <input
            type="number"
            name="periodsPerDay"
            value={settings.periodsPerDay}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Duration of Period (minutes):</label>
          <input
            type="number"
            name="durationPerPeriod"
            value={settings.durationPerPeriod}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>School Start Time:</label>
          <input
            type="time"
            name="schoolStartTime"
            value={settings.schoolStartTime}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>School End Time:</label>
          <input
            type="time"
            name="schoolEndTime"
            value={settings.schoolEndTime}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Assembly Start Time:</label>
          <input
            type="time"
            name="assemblyStartTime"
            value={settings.assemblyStartTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Assembly End Time:</label>
          <input
            type="time"
            name="assemblyEndTime"
            value={settings.assemblyEndTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Lunch Break Start Time:</label>
          <input
            type="time"
            name="lunchStartTime"
            value={settings.lunchStartTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Lunch Break End Time:</label>
          <input
            type="time"
            name="lunchEndTime"
            value={settings.lunchEndTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Short Break 1 Start Time:</label>
          <input
            type="time"
            name="shortBreak1StartTime"
            value={settings.shortBreak1StartTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Short Break 1 End Time:</label>
          <input
            type="time"
            name="shortBreak1EndTime"
            value={settings.shortBreak1EndTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Short Break 2 Start Time:</label>
          <input
            type="time"
            name="shortBreak2StartTime"
            value={settings.shortBreak2StartTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Short Break 2 End Time:</label>
          <input
            type="time"
            name="shortBreak2EndTime"
            value={settings.shortBreak2EndTime}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Reserve Type:</label>
          <select name="reserveType" value={settings.reserveType} onChange={handleChange}>
            <option value="time">Time</option>
            <option value="day">Day</option>
          </select>
        </div>
        {settings.reserveType === 'day' && (
          <>
            <div>
              <label>Reserve Day(s):</label>
              <div>
                {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                  <label key={day}>
                    <input
                      type="checkbox"
                      name="reserveDay"
                      value={day}
                      checked={settings.reserveDay.includes(day)}
                      onChange={handleChange}
                    />
                    {day}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label>Reserve Day Start Time:</label>
              <input
                type="time"
                name="reserveDayStart"
                value={settings.reserveDayStart}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>Reserve Day End Time:</label>
              <input
                type="time"
                name="reserveDayEnd"
                value={settings.reserveDayEnd}
                onChange={handleChange}
              />
            </div>
          </>
        )}
        {settings.reserveType === 'time' && (
          <>
            <div>
              <label>Reserve Time Start:</label>
              <input
                type="time"
                name="reserveTimeStart"
                value={settings.reserveTimeStart}
                onChange={handleChange}
              />
            </div>
            <div>
              <label>Reserve Time End:</label>
              <input
                type="time"
                name="reserveTimeEnd"
                value={settings.reserveTimeEnd}
                onChange={handleChange}
              />
            </div>
          </>
        )}
        <button type="submit">Save Timetable Settings</button>
      </form>
    </div>
  );
};

export default TimetableSettings;

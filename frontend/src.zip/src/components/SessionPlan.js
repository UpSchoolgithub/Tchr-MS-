import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const SessionPlans = () => {
  const { sessionId } = useParams();
  const [sessionPlans, setSessionPlans] = useState([]);
  const [numberOfSessions, setNumberOfSessions] = useState(0);
  const [topicNames, setTopicNames] = useState({});
  const [editing, setEditing] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchSessionPlans = async () => {
      try {
        const sessionResponse = await axios.get(`http://localhost:5000/api/sessions/${sessionId}`);
        setNumberOfSessions(sessionResponse.data.numberOfSessions);

        const response = await axios.get(`http://localhost:5000/api/sessions/${sessionId}/sessionPlans`);
        setSessionPlans(response.data);
        const initialTopicNames = response.data.reduce((acc, plan) => {
          acc[plan.sessionNumber] = plan.planDetails;
          return acc;
        }, {});
        setTopicNames(initialTopicNames);
      } catch (error) {
        console.error('Error fetching session plans:', error);
        setError('Failed to fetch session plans.');
      }
    };

    fetchSessionPlans();
  }, [sessionId]);

  const handleInputChange = (sessionNumber, value) => {
    setTopicNames(prevState => ({
      ...prevState,
      [sessionNumber]: value
    }));
  };

  const handleSaveTopic = async (planId, sessionNumber) => {
    setError('');
    try {
      const planDetails = topicNames[sessionNumber];
      const response = planId
        ? await axios.put(`http://localhost:5000/api/sessionPlans/${planId}`, { planDetails })
        : await axios.post(`http://localhost:5000/api/sessions/${sessionId}/sessionPlans`, { planDetails, sessionNumber });
      setSessionPlans(prevPlans =>
        prevPlans.map(plan =>
          plan.sessionNumber === sessionNumber ? response.data : plan
        )
      );
      setEditing(prevEditing => ({ ...prevEditing, [sessionNumber]: false }));
    } catch (error) {
      console.error('Error saving topic:', error);
      if (error.response && error.response.data) {
        setError(error.response.data.error);
      }
    }
  };

  const handleDeleteTopic = async (planId) => {
    try {
      await axios.delete(`http://localhost:5000/api/sessionPlans/${planId}`);
      setSessionPlans(sessionPlans.filter(plan => plan.id !== planId));
    } catch (error) {
      console.error('Error deleting topic:', error);
    }
  };

  const startEditing = (sessionNumber) => {
    setEditing(prevEditing => ({ ...prevEditing, [sessionNumber]: true }));
  };

  const cancelEditing = (sessionNumber) => {
    setEditing(prevEditing => ({ ...prevEditing, [sessionNumber]: false }));
  };

  return (
    <div>
      <h2>Session Plans</h2>
      {error && <div className="error">{error}</div>}
      <table>
        <thead>
          <tr>
            <th>Session Number</th>
            <th>Topic Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {[...Array(numberOfSessions)].map((_, index) => {
            const sessionNumber = index + 1;
            const existingPlan = sessionPlans.find(plan => plan.sessionNumber === sessionNumber);

            return (
              <tr key={sessionNumber}>
                <td>{sessionNumber}</td>
                <td>
                  <input
                    type="text"
                    value={topicNames[sessionNumber] || ''}
                    onChange={(e) => handleInputChange(sessionNumber, e.target.value)}
                    disabled={!editing[sessionNumber]}
                  />
                </td>
                <td>
                  {editing[sessionNumber] ? (
                    <>
                      <button onClick={() => handleSaveTopic(existingPlan ? existingPlan.id : null, sessionNumber)}>Save</button>
                      <button onClick={() => cancelEditing(sessionNumber)}>Cancel</button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => startEditing(sessionNumber)}>Edit</button>
                      {existingPlan && (
                        <button onClick={() => handleDeleteTopic(existingPlan.id)}>Delete</button>
                      )}
                    </>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default SessionPlans;

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import School from './components/School';
import Manager from './components/Manager';
import CreateSchool from './components/CreateSchool';
import EditSchool from './components/EditSchool';
import SchoolDetails from './components/SchoolDetails';
import TimetableSettings from './components/TimetableSettings';
import SchoolCalendar from './components/SchoolCalendar';
import ClassInfo from './components/ClassInfo';
import Members from './components/Members';
import SchoolPage from './pages/SchoolPage';
import SessionManagement from './components/SessionManagement';
import SessionPlan from './components/SessionPlan';
import AddSection from './components/AddSection';

function App() {
  return (
    <Router>
      <div className="app">
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/school" element={<School />} />
            <Route path="/manager" element={<Manager />} />
            <Route path="/create-school" element={<CreateSchool />} />
            <Route path="/edit-school/:id" element={<EditSchool />}>
              <Route path="details" element={<SchoolDetails />} />
              <Route path="timetable" element={<TimetableSettings />} />
              <Route path="calendar" element={<SchoolCalendar />} />
              <Route path="classes" element={<ClassInfo />} />
              <Route path="members" element={<Members />} />
            </Route>
            <Route path="/schools/:schoolId/*" element={<SchoolPage />}>
              <Route path="classes/:classId/sections/:sectionId/sessions" element={<SessionManagement />} />
            </Route>
            <Route path="/sessions/:sessionId/sessionPlans" element={<SessionPlan />} /> {/* Add this line */}
            <Route path="/add-section" element={<AddSection />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;

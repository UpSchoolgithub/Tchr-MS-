import React from 'react';
import { useParams, Outlet } from 'react-router-dom';

const SchoolPage = () => {
  const { schoolId } = useParams();

  console.log('SchoolPage: schoolId:', schoolId); // Should log the actual schoolId or undefined

  return (
    <div>
      <h1>School Page</h1>
      <Outlet context={{ schoolId }} />
    </div>
  );
};

export default SchoolPage;

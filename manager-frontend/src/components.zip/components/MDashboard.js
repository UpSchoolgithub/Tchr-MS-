import React from 'react';

const MDashboard = () => {
  return (
    <div>
      <h1>Dashboard</h1>
      {/* This is where you can add additional components or content for the dashboard */}
    </div>
  );
};

export default MDashboard;

const config = {
    API_BASE_URL: 'https://tms.up.school/api'
  };
  
  export default config;
  